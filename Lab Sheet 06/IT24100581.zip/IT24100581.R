setwd("C:\\Users\\sinol\\OneDrive\\Desktop\\IT24100581")

# Exercise 1
n <- 50              
p <- 0.85            
x <- 47:50          

# i. Distribution
# X ~ Binomial(n=50, p=0.85)

# ii. Probability at least 47 students pass
prob_at_least_47 <- sum(dbinom(x, size = n, prob = p))
prob_at_least_47

# Exercise 2
lambda <- 12   

# i. Random variable: X = number of calls per hour
# ii. Distribution: X ~ Poisson(lambda=12)

# iii. Probability that exactly 15 calls are received
prob_15 <- dpois(15, lambda)
prob_15
